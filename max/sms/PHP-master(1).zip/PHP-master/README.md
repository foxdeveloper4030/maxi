# PHP

PHP sample code to connect to sadad gateway
